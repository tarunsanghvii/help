import "./App.css";
import SideBar from "./components/Sidebar/SideBar";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import Navbar from "./components/Navbar";
import Analytics from "./pages/Analytics";
import FDashboard from "./pages/FDashboard";
import TDashboard from "./pages/TDashboard";
import TurbineDashboard from "./pages/Turbine";
import Nacelle from "./pages/Nacelle";
import Gearbox from "./pages/GearBox";
import Generator from "./pages/Generator";
import Notification from "./pages/Notification";
import Maintenance from "./pages/Maintenance";



function App() {
  return (
    <Router>
      <SideBar>
      <Navbar />
        <Routes>
          <Route exact path="/" element={<FDashboard />} />
          <Route exact path="/turbineSelector" element={<TDashboard />} />
          <Route exact path="/turbine" element={<TurbineDashboard/>} />
          <Route exact path="/nacelle" element={<Nacelle />} />
          <Route exact path="/gearbox" element={<Gearbox />} />
          <Route exact path="/notification" element={<Notification />} />
          <Route exact path="/generator" element={<Generator />} />
          <Route exact path="/analytics" element={<Analytics />} />
          <Route exact path="/maintenance" element={<Maintenance />} />

          <Route path="*" element={<> not found</>} />
        </Routes>
      </SideBar>
    </Router>
  );
}

export default App;
