import React from 'react'

export default function Turbine() {
  return (
    <div>Turbine</div>
  )
}
