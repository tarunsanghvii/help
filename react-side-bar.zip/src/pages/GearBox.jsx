import React from 'react'

export default function GearBox() {
  return (
    <div className='title'>GearBox</div>
  )
}
