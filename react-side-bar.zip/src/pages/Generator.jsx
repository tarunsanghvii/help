import React from 'react'

export default function Generator() {
  return (
    <div>Generator</div>
  )
}
