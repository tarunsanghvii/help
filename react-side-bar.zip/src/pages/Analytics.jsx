import React from 'react'

export default function Analytics() {
  return (
    <div className="title">Analytics</div>
  )
}
