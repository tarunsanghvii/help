import React from 'react'

export default function Maintenance() {
  return (
    <div className='title'>Maintenance</div>
  )
}
