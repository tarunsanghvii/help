import React from 'react'

export default function TDashboard() {
  return (
    <div className="title">TDashboard</div>
  )
}
