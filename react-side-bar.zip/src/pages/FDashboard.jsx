import React from 'react'

export default function FDashboard() {
  return (
    <div className="title">FDashboard</div>
  )
}
