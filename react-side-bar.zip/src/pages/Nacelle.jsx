import React from 'react'

export default function Nacelle() {
  return (
    <div>Nacelle</div>
  )
}
