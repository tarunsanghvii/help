import React from 'react'

export default function Card() {
  return (
        <div className="row" style={{'--bs-gutter-x':'0rem'}}>
            {/* 1st */}
            <div className="col rounded-custom my-2" style={{'marginLeft':'0.5rem'}}>
                <div className='row-1 rounded-custom my-1 card-border' style={{'minHeight': '12vh'}}>
                    <span className="text-black font-weight-normal fs-6">Temperature</span>
                    <span className="d-block my-2">    
                        <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                        <b id="nacelleTemp">0</b>°C
                        </h6>
                    </span>
                </div>
                <div className='row-2 rounded-custom my-1 card-border' style={{'minHeight': '12vh'}}>
                    <span className="text-black font-weight-normal fs-6">Blade Rotation</span>
                    <span className="d-block my-2">    
                        <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                        <b id="nacelleTemp">0</b>RPS
                        </h6>
                    </span>
                </div>
                
            </div>
            {/* Acc */}
            <div className="col rounded-custom card-border mx-2 my-2">
                <span className="text-black font-weight-normal fs-6">Acceleration</span>    
                <span className="d-block my-2">    
                    <span className="text-black fw-normal  fs-sm-4-acc mt-2 "><b id="acc-x">0</b> x-axis<br/></span>
                    <span className="text-black fw-normal  fs-sm-4-acc mt-2 "><b id="acc-y">0</b> y-axis<br/></span>
                    <span className="text-black fw-normal  fs-sm-4-acc mt-2 "><b id="acc-z">0</b> z-axis</span>
                </span>
            </div>
            {/* connectivity */}
            <div className="col rounded-custom card-border mx-2 my-2">
                <span className="text-black font-weight-normal fs-6">Connectivity</span>
                <span className="d-block my-2">    
                    <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                    <b id="nacelleTemp">Connected</b><br />WindTurbine
                    </h6>
                </span>
            </div>
            {/* Health */}
            <div className="col rounded-custom card-border mx-2 my-2">
                <span className="text-black font-weight-normal fs-6">Healh</span>
                <span className="d-block my-2">    
                    <h6 className="text-black fw-bold  fs-sm-6-nacelle mt-2">
                    <b id="nacelleTemp">Alert</b>
                    </h6>
                </span>
            </div>
            {/* weather */}
            <div className="col rounded-custom card-border mx-2 my-2">
                <span className="text-black font-weight-normal fs-6">Weather</span>
                <span className="d-block my-2">    
                    <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                    <b id="nacelleTemp">Patchy Rain</b><br />01/04/22 @15:32hrs      
                    </h6>
                </span>
            </div>
            {/* Maintenace */}
            <div className="col rounded-custom card-border mx-2 my-2">
                <span className="text-black font-weight-normal fs-6">Maintenance</span>
                <span className="d-block my-2">    
                    <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                    <b id="nacelleTemp">12/02/22</b><br />Last Done
                    </h6>
                    <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                    <b id="nacelleTemp">12/02/22</b><br />Upcoming
                    </h6>
                </span>
            </div>
            {/* Downtime */}
            <div className="col rounded-custom card-border my-2" style={{'marginRight':'0.5rem'}}>
                <span className="text-black font-weight-normal fs-6">Downtime</span>
                <span className="d-block my-2">    
                    <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                    <b id="nacelleTemp">03:00 hrs</b><br />Last Week
                    </h6>
                    <h6 className="text-black fw-normal  fs-sm-6-nacelle mt-2">
                    <b id="nacelleTemp">01:05 hrs</b><br />Unplanned
                    </h6>
                </span>
            </div>
        </div>
  )
}
