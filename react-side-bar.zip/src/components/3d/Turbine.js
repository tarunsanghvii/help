import React,{ Suspense } from 'react'
import { Canvas } from "@react-three/fiber";
import WindTurbine from "./Windturbine";
import { OrbitControls } from "@react-three/drei";
import { Camera } from 'three';
import nacelle from '../../assets/images/nacelle-removebg.png';
import gearbox from '../../assets/images/gearbox.png';
import generator from '../../assets/images/generator-removebg.png';

export default function Turbine() {
  return (
    <>
        <div className="row my-3" style={{'--bs-gutter-x':'0rem'}}>
        {/* this is 3D render */}
            <div className='mx-auto col-lg-9 ' style={{'borderRadius': '1rem',border:' 1px solid',height:'612px'}}>
                <Canvas>
                    {/* <color attach="background" args={"#D7EFEB"} /> */}
                    <OrbitControls/>
                    <directionalLight intensity={4} />
                    {/* <Camera /> */}
                    <ambientLight intensity={0.2} />
                    <Suspense fallback={null}>
                    {/* <Walk /> */}
                    <WindTurbine />
                    </Suspense>
                </Canvas>
            </div>
            {/* This is side components */}
            <div className="mx-auto col-lg-2" style={{height:'600px'}}>
                <div className='row-lg rounded-custom  card-border' style={{position:'relative',flexDirection:'column',minWidth:'0',wordWrap: 'break-word',minHeight: '32vh',width: '14rem'}}>Naclle<br />
                <img src={nacelle} alt='Nacelle-Img' style={{width:'70%',height:'auto'}} />
                {/* <img src={nacelle} className="img-fluid" alt="Nacelle-Img" style={{maxWidth:'70% !important'}}/> */}
                <br/>Temperature : 29.8 *C<br/>
                Humidity : 29.8 %rh
                </div>
                <div className='row-lg my-1 rounded-custom  card-border' style={{position:'relative',flexDirection:'column',minWidth:'0',wordWrap: 'break-word',minHeight: '32vh',width: '14rem'}}>Gearbox<br />
                <img src={gearbox} alt='Gearbox-Img' style={{width:'70%',height:'auto'}} />
                {/* <img src={nacelle} className="img-fluid" alt="Nacelle-Img" style={{maxWidth:'70% !important'}}/> */}
                <br/>Temperature : 29.8 *C
                </div>
                <div className='row-lg mb-2 rounded-custom  card-border' style={{position:'relative',flexDirection:'column',minWidth:'0',wordWrap: 'break-word',minHeight: '32vh',width: '14rem'}}>Generator<br />
                <img src={generator} alt='Generator-Img' style={{width:'70%',height:'auto'}} />
                {/* <img src={nacelle} className="img-fluid" alt="Nacelle-Img" style={{maxWidth:'70% !important'}}/> */}
                <br/>Temperature : 29.8 *C<br/>
                Vibration : 100
                <br />
                Humidity : 29.8 %rh
                </div>
            </div>
        </div>
    </>
  )
}
