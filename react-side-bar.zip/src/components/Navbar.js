import React from 'react'
import PropTypes from 'prop-types'

export default function Navbar(props) {
  return (
    <nav className={`navbar navbar-expand-lg navbar-light bg-light dark-color`}>
        <div className="container-fluid">
        <a className="navbar-brand" href="/">{props.title}</a>
        <form className="d-flex">
        <div className="form-check form-switch mx-2">
        </div>
        <p className='mx-2' style={{'alignSelf': 'center'}}>Hi,Winduser</p>
        <p className="btn btn-outline-success">W</p>   
        </form>
        </div>
    </nav>
  )
}

Navbar.propTypes ={
    title: PropTypes.string.isRequired,
    about: PropTypes.string
}
Navbar.defaultProps = {
    title: 'Yash',
    about: 'About Us'
}
