import * as React from "react";

const SvgStockholmIconsWeatherTemperatureHalf = (props) => (
  <svg
    data-name="Stockholm-icons-/-Weather-/-Temperature-half"
    xmlns="http://www.w3.org/2000/svg"
    width="1em"
    height="1em"
    viewBox="0 0 24 24"
    {...props}
  >
    <path d="M0 0h24v24H0Z" fill="none" />
    <path
      d="M18 16a6 6 0 1 1-9-5.2V5a3 3 0 0 1 6 0v5.8a6 6 0 0 1 3 5.2ZM12 4a1 1 0 0 0-1 1v5a1 1 0 0 0 2 0V5a1 1 0 0 0-1-1Z"
      fill="currentColor"
    />
  </svg>
);

export default SvgStockholmIconsWeatherTemperatureHalf;
